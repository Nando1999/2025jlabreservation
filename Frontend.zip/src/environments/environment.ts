export const environment = {
  socketUrl: 'http://localhost:8080',
  urlBase: 'http://localhost:8080/api/v1',
  urlAuth: '/auth',
  urlUser: '/user',
  production: true
};
