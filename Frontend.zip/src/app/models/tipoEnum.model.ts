export enum TipoEnum {
    RESERVA = 'RESERVA',
    CLASE = 'CLASE',
    TUTORIA = 'TUTORIA',    
}