package com.masache.masachetesis.models;

public enum DiaEnum {
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES,
    VIERNES;
}
